trans-neptunian object
======================

v1.0
skin for winamp / wacup :3


credits
=======

template: https://skins.webamp.org/skin/185c5fe89f505e17746919888589b061/Skinner_Atlas.wsz/
font: http://www.pentacom.jp/pentacom/bitfontmaker2/gallery/?id=372